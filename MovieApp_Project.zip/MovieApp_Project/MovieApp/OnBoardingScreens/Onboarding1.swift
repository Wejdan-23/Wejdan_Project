//
//  Onboarding1.swift
//  MovieApp
//
//  Created by Abdullah Aloufi on 04/07/1444 AH.
//

import SwiftUI

struct Onboarding1: View {
    @Binding var shouldShowOnboarding: Bool
    var body: some View {
        TabView {
            OBPageView(
                title: "Push Notifications",
                subtitle: "Enable notifications to stay up to date with friends.",
                imageName: "bell",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
//                .frame(width: 350 )
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
                title: "Bookmarks",
                subtitle: "Save your favorite pieces of content.",
                imageName: "bookmark",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding).padding()
//                .frame(width: 350 )
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
                title: "Bookmarks",
                subtitle: "Save your favorite pieces of content.",
                imageName: "bookmark",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding).padding()
//                .frame(width: 350 )
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
                title: "Flights",
                subtitle: "Book flights to the places you want to go.",
                imageName: "airplane",
                showsDismissButton: false,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
//                .frame(width: 350 )
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
            OBPageView(
                title: "Home",
                subtitle: "Go home whereever you might be",
                imageName: "house",
                showsDismissButton: true,
                shouldShowOnboarding: $shouldShowOnboarding
            ).padding()
//                .frame(width: 350 )
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .shadow(color: Color.secondary, radius: 100, x: 5, y: 5)
        }
        .tabViewStyle(PageTabViewStyle())
        
    }
}

//struct Onboarding1_Previews: PreviewProvider {
//    static var previews: some View {
//        Onboarding1(shouldShowOnboarding: true)
//    }
//}
