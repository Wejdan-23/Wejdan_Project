//
//  Constants.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct Images {
    static let bg1 = Image("bg1")
    static let bg2 = Image("bg2")
    static let bg3 = Image("bg3")
    static let bg4 = Image("bg4")
}

struct Colors {
    static let color1 = Color(hex:"")
    static let color2 = Color(hex:"")
}
