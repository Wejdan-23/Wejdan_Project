//
//  Fovirite.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import Foundation

struct Favorites {
    var movie: Movie
    var userId: UUID
}
