//
//  Movie.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

enum Genre: String {
    case Action, Comedy, Drama, Thriller, History, Documentary, Animation, SciFi, Horror
}

enum OnAirStatus: String {
    case Playing, ComingSoon = "Coming Soon", NotInThreater = "Not in theater"
}

struct Movie: Identifiable {
    var id = UUID()
    var title: String
    var genre: Set<Genre>
    var duration: String
    var description: String
    var poster: Image
    var cast: [Cast]
    var review: Double
    var numReviews: Int
    var onAirStatus: OnAirStatus
}

extension Movie {
    static let movies: [Movie] = [
        .init(title: "Spider Man", genre: [.Action], duration: "02:00", description: "spider man spider man", poster: Images.bg1, cast: [Cast(name: "Parker", image: Images.bg1)], review: 3.5, numReviews: 4000, onAirStatus: .Playing),
        .init(title: "Bat Man", genre: [.Action, .Thriller, .Animation], duration: "01:50", description: "Bruce Wayne", poster: Images.bg1, cast: [Cast(name: "Bruce", image: Images.bg1)], review: 4.5, numReviews: 7000, onAirStatus: .Playing),
        .init(title: "Super Man", genre: [.Action], duration: "02:15", description: "Cryptonight", poster: Images.bg1, cast: [Cast(name: "Clark", image: Images.bg1)], review: 4.3, numReviews: 9000, onAirStatus: .ComingSoon)
    ]
}

