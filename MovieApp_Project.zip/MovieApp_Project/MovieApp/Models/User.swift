//
//  User.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

struct User: Identifiable {
    var id = UUID()
    var name: String
    var email: String
    var password: String
    var image: Image
    var favorites: [Favorites]
}

extension User {
    static var users = [
        User(name: "Amer", email: "amer@example.com", password: "Password", image: Images.bg1, favorites: []),
        User(name: "Wejdan", email: "wejdan@exanple.com", password: "Password", image: Images.bg1, favorites: []),
        User(name: "Abdullah", email: "abdullah@example.com", password: "Password", image: Images.bg1, favorites: [])
    ]
}
