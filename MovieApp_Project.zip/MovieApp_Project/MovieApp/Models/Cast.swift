//
//  Cast.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

struct Cast {
    var name: String
    var image: Image
}
