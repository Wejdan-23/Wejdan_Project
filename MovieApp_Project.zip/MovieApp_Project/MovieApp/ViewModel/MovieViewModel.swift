//
//  MovieViewModel.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import Foundation

class MovieViewModel: ObservableObject {
    @Published var movies = Movie.movies
    
    func filterBy(title: String) {
        movies = title.isEmpty ? movies : movies.filter {$0.title.contains(title)}
    }
    
    func filterBy(genre: Genre?) {
        movies = genre == nil ? movies : movies.filter {$0.genre.contains(genre!)}
    }
}
