//
//  ContentView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct ContentView: View {
  // @State var DarkMode:String
   //  Toggle("DarkMode",isOn: $DarkMode)
    var body: some View {
        OnboardingView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
       ZStack{
          GeometryReader{ _ in

             ZStack{
                SignInView()


             }


          }


       }
      ContentView()
    }
}
