//
//  ProfileListRow.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

struct ProfileListRow: View {
    var title: String
    var textColor: Color
    @Binding var toggleAction: Bool
    
    var body: some View {
        Toggle(title, isOn: $toggleAction)
            .font(.body)
            .foregroundColor(textColor)
            .listRowBackground(Color.clear)
            .tint(.purple)
    }
}
