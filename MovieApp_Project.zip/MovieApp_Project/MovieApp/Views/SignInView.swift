//  know key
//  add language: project >InFo> add Arabic
//  add catalog(all keys project): product>Export localization
// after updata the catalog > seve> go to Xcode>product>import>open file> choose a file> import
// product>import localization
//product > scheme > Eidtscheme > app language
//
//

// 


import SwiftUI
struct SignInView: View {
   
    @State var username = ""
    @State var email = ""
    @State var password = ""
    @State var confirmPassword = ""
   // know variable that changes text based on the language
   var usernameK: String {
      // know key
      let format = NSLocalizedString("userNameL", comment:"")
      return String.localizedStringWithFormat(format)
   }
   var passwordK: String {
      let format = NSLocalizedString("passwordL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var emailK: String {
      let format = NSLocalizedString("emailL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var SignUPK: String {
      let format = NSLocalizedString("SignUPL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var accountK: String {
      let format = NSLocalizedString("accountL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var SubmitK: String {
      let format = NSLocalizedString("SubmitL", comment: "")
      return String.localizedStringWithFormat(format)
   }
    var body: some View {
        ZStack {
           
            Images.bg4
                .resizable()
                .scaledToFill()
                .ignoresSafeArea(.all)

           VStack {
              ZStack {
                 // MARK: - UserName
                 VStack{
                     HStack {
                         Text(usernameK)
                              .font(.title2)
                              .bold()
                              .foregroundColor(.primary)
                         Spacer()
                     }
                     .padding()
                     
                    HStack {
                        Image(systemName: "person")
                            .foregroundColor(.blue)
                            .font(.title3)
                       TextField("username", text: $username)
                            .font(.title3)
                            .foregroundColor(.primary)
                    }
                    .padding()
                    .background(.regularMaterial, in: Capsule())
                    
                     // MARK: - Email
                     HStack {
                         Text(emailK)
                              .font(.title2)
                              .foregroundColor(.primary)
                              .bold()
                         Spacer()
                     }
                     .padding()
                     HStack {
                         Image(systemName: "envelope.open")
                             .foregroundColor(.green)
                             .font(.title3)
                         TextField("example@gmail.com", text: $email)
                             .foregroundColor(.primary)
                             .font(.title3)
                     }
                     .padding()
                     .background(.regularMaterial, in: Capsule())
                     
                     HStack {
                         Text(passwordK)
                            .font(.title2)
                            .foregroundColor(.primary)
                            .bold()
                         Spacer()
                     }
                     .padding()
                     
                    HStack{
                       Image(systemName: "lock")
                            .foregroundColor(Color.red)
                            .font(.title3)
                       SecureField("********", text: $password)
                            .foregroundColor(.primary)
                            .font(.title3)
                    }
                    .padding()
                    .background(.regularMaterial, in: Capsule())

                     HStack {
                         Text(accountK)
                             .foregroundColor(.primary)
                             .font(.body)
                         NavigationLink(destination: SignUpView()) {
                             Text(SignUPK)
                                 .font(.title3)
                                 .bold()
                         }
                     }
                     .padding(24)
                 }
                 .padding()
                 .frame(width: UIScreen.main.bounds.width - 80)
              }
              .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))

               // Hide Back Button When Navigating
               NavigationLink(destination: MainTabView().navigationBarBackButtonHidden(true)) {
                  
                   Text(SubmitK)
                       .font(.title2)
                       .bold()
                       .foregroundColor(Color.primary)
                       .frame(width: UIScreen.main.bounds.width - 120)
                       .padding()
                       .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16)).padding()
               }
           }
           .padding()
            
        }
    }
}

struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
//         .preferredColorScheme(.dark)
    }
}
