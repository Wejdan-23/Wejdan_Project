//
//  OnboardingView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct OnboardingView: View {
    @State var shouldShowOnboarding: Bool = true
    var body: some View {
        NavigationStack {
            ZStack {
                Images.bg4
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
                VStack {
                    // MARK: - Design You View Here
                    
                    Text("Onboarding View")
                        .foregroundColor(Color.primary)
                        .font(.largeTitle)
                        .padding()
                        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                    
                    Spacer()
                        
                    NavigationLink(destination: SignInView()) {
                        Text("Take me to Sign in View")
                            .foregroundColor(Color.primary)
                            .padding()
                            .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                    }
                }
                .padding()
            }
            
        }.fullScreenCover (isPresented: $shouldShowOnboarding, content: {
            Onboarding1(shouldShowOnboarding: $shouldShowOnboarding)
        })
    }
}

struct OnboardingView_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingView()
    }
}
