//
//  MoviesView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct MoviesView: View {
    
    @State private var searchText = ""
    @State private var tabSelection = 1
    
    var movies = Movie.movies

    var body: some View {
        ZStack {
            Images.bg4
                .resizable()
                .ignoresSafeArea(.all, edges: .top)
            
            VStack {
                // MARK: - Title
                Text("Movies View")
                    .foregroundColor(Color.primary)
                    .font(.largeTitle)
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                // MARK: - Search Bar
                TextField("Serch Movie", text: $searchText)
                    .textFieldStyle(.plain)
                    .font(.body)
                    .padding()
                    .foregroundColor(Color.primary)
                    .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
                
                VStack {
                    ScrollView(.vertical) {
                        List(movies) { movie in
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(.blue)
                            Text(movie.title)
                                .foregroundColor(Color.primary)
                        }
                    }
                    .onAppear{ print("\(Movie.movies.count)") }
                }
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
                .padding()
            }
            .padding()
        }
    }
}

//struct MoviesView_Previews: PreviewProvider {
//    static var previews: some View {
//        MoviesView()
//    }
//}
