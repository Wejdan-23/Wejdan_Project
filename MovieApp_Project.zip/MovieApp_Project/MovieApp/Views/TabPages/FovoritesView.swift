//
//  FovoritesView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 24/01/2023.
//

import SwiftUI

struct FavoriteView: View {
    var body: some View {
        Text("Favorites View")
    }
}

struct FovoritesView_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteView()
    }
}
