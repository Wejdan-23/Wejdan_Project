//
//  ReservedTicketsView.swift
//  MovieApp
//
//  Created by Amer Alyusuf on 25/01/2023.
//

import SwiftUI

struct ReservedTicketsView: View {
    var body: some View {
        ZStack {
            Images.bg4
                .resizable()
                .scaledToFill()
                .ignoresSafeArea(.all, edges: .top)
            VStack {
                // MARK: - Design You View Here
                Text("Reserved Tickets View")
                    .foregroundColor(Color.primary)
                    .font(.largeTitle)
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                Spacer()
            }
            .padding()
        }
    }
}

//struct ReservedTicketsView_Previews: PreviewProvider {
//    static var previews: some View {
//        ReservedTicketsView()
//    }
//}
