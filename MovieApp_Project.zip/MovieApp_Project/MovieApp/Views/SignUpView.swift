//
//  SignUpView.swift
//  MovieApp
//
//  Created by Judy Alshahrani on 03/07/1444 AH.
//

import SwiftUI

struct SignUpView: View {
   @State var email=""
   @State var password=""
   @State var username = ""
   // know variable that changes text based on the language
   var usernameK: String {
      // know key
      let format = NSLocalizedString("userNameL", comment:"")
      return String.localizedStringWithFormat(format)
   }
   var passwordK: String {
      let format = NSLocalizedString("passwordL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var emailK: String {
      let format = NSLocalizedString("emailL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var SignUPK: String {
      let format = NSLocalizedString("SignUPL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var comfirmPassK: String {
      let format = NSLocalizedString("comfirmPassKL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   var AlreadyaccounK: String {
      let format = NSLocalizedString("AlreadyaccounKL", comment: "")
      return String.localizedStringWithFormat(format)
   }
   @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
   
    var body: some View {
       ZStack {
          Images.bg1
             .resizable()
             .scaledToFill()
             .ignoresSafeArea(.all)

          // MARK: - UserName
          VStack{
              HStack {
                  Text(usernameK)
                       .font(.title2)
                       .bold()
                       .foregroundColor(.primary)
                  Spacer()
              }
              .padding()
              
             HStack {
                 Image(systemName: "person")
                     .foregroundColor(.blue)
                     .font(.title3)
                TextField("username", text: $username)
                     .font(.title3)
                     .foregroundColor(.primary)
                 
             }
             .padding()
             .background(.regularMaterial, in: Capsule())
                HStack {
                   Text(emailK)
                      .font(.title2)
                      .bold()
                      .foregroundColor(.primary)
                   Spacer()
                }
                HStack {
                   Image(systemName: "envelope.open")
                      .foregroundColor(.green)
                      .font(.title3)
                   TextField(" example@gmail.com :", text: $email)
                      .font(.title3)
                      .foregroundColor(.primary)
                   
                }
                .padding()
                .background(.regularMaterial, in: Capsule())
            
                HStack {
                   Text(passwordK)
                      .font(.title2)
                      .bold()
                      .foregroundColor(.primary)
                   Spacer()
                }
             HStack{
                Image(systemName: "lock")
                     .foregroundColor(Color.red)
                     .font(.title3)
                SecureField("********", text: $password)
                     .foregroundColor(.primary)
                     .font(.title3)
             }
             .padding()
             .background(.regularMaterial, in: Capsule())
                HStack {
                   Text(comfirmPassK)
                      .font(.title2)
                      .bold()
                      .foregroundColor(.primary)
                   Spacer()
                }
             HStack{
                Image(systemName: "lock")
                     .foregroundColor(Color.red)
                     .font(.title3)
                SecureField("********", text: $password)
                     .foregroundColor(.primary)
                     .font(.title3)
             }
             .padding()
             .background(.regularMaterial, in: Capsule())
                HStack{
                   
                   Button(SignUPK) { self.presentationMode.wrappedValue.dismiss() }
                   
                      .frame(width:280,height: 30)
                      .padding()
                      .background(Color.yellow.opacity(0.5).cornerRadius(20))
                      .foregroundColor(.black)
                      .font(.headline)
                   
                   
                }
                .padding()
                VStack(alignment:.center,spacing: 10){
                   Button{} label:{ Text(AlreadyaccounK)}
                }
                
             }
             .padding(40)
             .frame(width: UIScreen.main.bounds.width - 40)
             
             .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
             Spacer()
          }
      
          
       
       }
    }


struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}

